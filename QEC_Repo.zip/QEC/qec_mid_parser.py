import mido
from mido import MidiFile

def print_midi_messages(midi_file_path):
    midi_file = MidiFile(midi_file_path)
    for i, track in enumerate(midi_file.tracks):
        print(f"Track {i}: {track.name}")
        for msg in track:
            print(msg)

if __name__ == "__main__":
    import sys
    if len(sys.argv) != 2:
        print("Usage: python qec_mid_parser.py <midi_file_path>")
        sys.exit(1)
    print_midi_messages(sys.argv[1])
